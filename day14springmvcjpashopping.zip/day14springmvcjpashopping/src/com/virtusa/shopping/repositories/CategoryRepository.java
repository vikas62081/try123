package com.virtusa.shopping.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shopping.models.Category;

public interface CategoryRepository extends JpaRepository<Category,Integer>{

}
