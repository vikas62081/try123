package com.virtusa.shopping.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.UserRole;
import com.virtusa.shopping.repositories.UserRoleRepository;

@Service

public class UserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepository;
	
	public List<UserRole> getUserRoleByName(String userName)
	{
		return userRoleRepository.getUserRolesByName(userName);
	}
	
	
	
}
